#include "../head/duLinkedList.h"

/**
 *  @name        : Status InitList_DuL(DuLinkedList *L)
 *	@description : initialize an empty linked list with only the head node
 *	@param		 : L(the head node)
 *	@return		 : Status
 *  @notice      : None
 */
Status InitList_DuL(DuLinkedList *L) {
	DuLNode*h;
	
	if(h=(DuLNode*)malloc(sizeof(DuLNode))){
		h->prior=NULL;
		h->next=NULL;
		*L=h;
		printf("��ʼ�����\n");
		getch(); 
		return SUCCESS;
	}else
	return ERROR; 
}

/**
 *  @name        : void DestroyList_DuL(DuLinkedList *L)
 *	@description : destroy a linked list
 *	@param		 : L(the head node)
 *	@return		 : status
 *  @notice      : None
 */
void DestroyList_DuL(DuLinkedList *L) {
	DuLinkedList p,q;
	p=*L;
	while(p){
		q=p->next;
		free(p);
		p=q;
	}
	*L=NULL;
}

/**
 *  @name        : Status InsertBeforeList_DuL(DuLNode *p, LNode *q)
 *	@description : insert node q before node p
 *	@param		 : p, q
 *	@return		 : status
 *  @notice      : None
 */
Status InsertBeforeList_DuL(DuLNode *p, DuLNode *q) {
	if(q=(DuLNode*)malloc(sizeof(DuLNode))){
		printf("���������ݣ�");
		scanf("%d",&q->data); 
		q->prior=p->prior;
		q->next=p;
		if(p->prior){
			p->prior->next=q;	
		}
		p->prior=q;
		return SUCCESS;
	}
	return ERROR;
}

/**
 *  @name        : Status InsertAfterList_DuL(DuLNode *p, DuLNode *q)
 *	@description : insert node q after node p
 *	@param		 : p, q
 *	@return		 : status
 *  @notice      : None
 */
Status InsertAfterList_DuL(DuLNode *p, DuLNode *q) {
	if(q=(DuLNode*)malloc(sizeof(DuLNode))){
		printf("���������ݣ�");
		scanf("%d",&q->data); 
		q->prior=p;
		q->next=p->next;
		if(p->next){
			p->next->prior=q;
		}
		p->next=q;
		return SUCCESS;
	}
	return ERROR;
}

/**
 *  @name        : Status DeleteList_DuL(DuLNode *p, ElemType *e)
 *	@description : delete the first node after the node p and assign its value to e
 *	@param		 : p, e
 *	@return		 : status
 *  @notice      : None
 */
Status DeleteList_DuL(DuLNode *p, ElemType *e) {
	DuLNode*pt;
	if(p->next){
		
		pt=p->next;
		p->next=pt->next;
		if(pt->next){
			pt->next->prior=p;
		}
		*e=pt->data;
		free(pt);
		pt=NULL;
		return SUCCESS;
	}
	
	return ERROR;
}

/**
 *  @name        : void TraverseList_DuL(DuLinkedList L, void (*visit)(ElemType e))
 *	@description : traverse the linked list and call the funtion visit
 *	@param		 : L(the head node), visit
 *	@return		 : Status
 *  @notice      : None
 */
void TraverseList_DuL(DuLinkedList L, void (*visit)(ElemType e)) {
	for(;L;L=L->next){
		(*visit)(L->data);
	}
}

void print(ElemType e){
	printf("%d\t",e);	
}

void Print(DuLinkedList*L){
	printf("������");
	if(*L){
		DuLNode*p=(*L)->next;
		for(;p;p=p->next){
			printf("%d\t",p->data);
		}
	}else{
		printf("(��)"); 
	}
	printf("\n");
}
