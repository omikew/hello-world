#include "../head/linkedList.h"

/**
 *  @name        : Status InitList(LinkList *L);
 *	@description : initialize an empty linked list with only the head node without value
 *	@param		 : L(the head node)
 *	@return		 : Status
 *  @notice      : None
 */
Status InitList(LinkedList *L) {
	LNode*h;
	
	if(h=(LNode*)malloc(sizeof(LNode))){
		printf("���������ݣ�");
		scanf("%d",&h->data);
		h->next=NULL;
		*L=h;
		return SUCCESS;
	}else
	return ERROR; 
}

/**
 *  @name        : void DestroyList(LinkedList *L)
 *	@description : destroy a linked list, free all the nodes
 *	@param		 : L(the head node)
 *	@return		 : None
 *  @notice      : None
 */
void DestroyList(LinkedList *L) {
	
	LinkedList p,q;
	p=*L;
	while(p){
		q=p->next;
		free(p);
		p=q;
	}
	*L=NULL;
}

/**
 *  @name        : Status InsertList(LNode *p, LNode *q)
 *	@description : insert node q after node p
 *	@param		 : p, q
 *	@return		 : Status
 *  @notice      : None
 */
Status InsertList(LNode *p, LNode *q) {
	if(q=(LNode*)malloc(sizeof(LNode))){
		printf("���������ݣ�");
		scanf("%d",&q->data); 
		q->next=p->next;
		p->next=q;
		return SUCCESS;
	}
	return ERROR; 
}
/**
 *  @name        : Status DeleteList(LNode *p, ElemType *e)
 *	@description : delete the first node after the node p and assign its value to e
 *	@param		 : p, e
 *	@return		 : Status
 *  @notice      : None
 */
Status DeleteList(LNode *p, ElemType *e) {
	
	LNode*pt;
	if(p->next){
		
		pt=p->next;
		p->next=pt->next;
		*e=pt->data;
		free(pt);
		pt=NULL;
		return SUCCESS;
	}
	
	return ERROR;		 
}

/**
 *  @name        : void TraverseList(LinkedList L, void (*visit)(ElemType e))
 *	@description : traverse the linked list and call the funtion visit
 *	@param		 : L(the head node), visit
 *	@return		 : None
 *  @notice      : None
 */
void TraverseList(LinkedList L, void (*visit)(ElemType e)) {
	
	for(;L;L=L->next){
		(*visit)(L->data);
	}
}

/**
 *  @name        : Status SearchList(LinkedList L, ElemType e)
 *	@description : find the first node in the linked list according to e
 *	@param		 : L(the head node), e
 *	@return		 : Status
 *  @notice      : None
 */
Status SearchList(LinkedList L, ElemType e) {
	
	LNode*p;
	int i=1;
	p=L;
	while(p){
		if(p->data==e){
			printf("%d�ڵ�%d���ڵ�",e,i);
			return SUCCESS;
		}
		i++;
		p=p->next;
	}
	return ERROR;
}

/**
 *  @name        : Status ReverseList(LinkedList *L)
 *	@description : reverse the linked list
 *	@param		 : L(the head node)
 *	@return		 : Status
 *  @notice      : None
 */
Status ReverseList(LinkedList *L) {
	LNode*p,*pt;
	pt=NULL;
	if((*L)->next){
		
		while(*L){
			p=(*L)->next;
			(*L)->next=pt;
			pt=*L;
			*L=p;
		}
		*L=pt;
		return SUCCESS;
	}
	return ERROR;
}

/**
 *  @name        : Status IsLoopList(LinkedList L)
 *	@description : judge whether the linked list is looped
 *	@param		 : L(the head node)
 *	@return		 : Status
 *  @notice      : None
 */
Status IsLoopList(LinkedList L) {
	LNode*slow,*fast;
	
	slow=fast=L;
	do{
		slow=slow->next;
		fast=fast->next->next;
		if(!fast) break;
		if(!(fast->next)) break; 
	}while(slow!=fast);
	if(fast){
		printf("��ѭ������\n");
		getch();
		return SUCCESS;
	}
	printf("����ѭ������\n");
	getch();
	return ERROR;

}

/**
 *  @name        : LNode* ReverseEvenList(LinkedList *L)
 *	@description : reverse the nodes which value is an even number in the linked list, input: 1 -> 2 -> 3 -> 4  output: 2 -> 1 -> 4 -> 3
 *	@param		 : L(the head node)
 *	@return		 : LNode(the new head node)
 *  @notice      : choose to finish
 */
LNode* ReverseEvenList(LinkedList *L) {
	LNode*p,*pt;
	p=*L;
	if(p->next==NULL){
		printf("Only a node,error!\n");
		getch();
		return NULL;
	}
	if(p->next->next==NULL){
		pt=p->next->next;
		*L=p->next;
		p->next->next=p;
		p->next=pt;
		return NULL;
	}
	while(p->next&&p->next->next){
		pt=p->next->next;
		if(p==*L){
			*L=p->next;
			p->next->next=p;
			p->next=pt;
		
		}else{
			p->next->next=pt->next;
			pt->next=p->next;
			p->next=pt;
			p=p->next->next;
		}
		
	} 
}

/**
 *  @name        : LNode* FindMidNode(LinkedList *L)
 *	@description : find the middle node in the linked list
 *	@param		 : L(the head node)
 *	@return		 : LNode
 *  @notice      : choose to finish
 */
LNode* FindMidNode(LinkedList *L) {
	LNode*slow,*fast;
	
	slow=fast=*L;
	if((*L)->next==NULL){
		printf("Only head node,error!\n");
		getch();
		return NULL;
	}
	while(1){
		slow=slow->next;
		fast=fast->next->next;
		if(!fast){
			printf("�м���Ϊ��%d",slow->data);
			getch();
			return slow;
		}
		if(!(fast->next)){
			printf("�м���Ϊ��%d",slow->data);
			getch();
			return slow;
		}
	}
}

void Print(LinkedList*L){
	LNode*p=*L;
	printf("������");
	if(!(*L)){
		printf("(��)"); 
	} 
	for(;p;p=p->next){
		printf("%d\t",p->data);
	}
	printf("\n");
}

void print(ElemType e){
	printf("%d\t",e);	
}
